# V2 numerical test: cluster package

This package runs the first numerical experiment in the V2 design. It is not
the 32-model extinction search or the 24-case material pilot.

The array has **20 tasks**: two nominal inclinations (50°, 70°), five seeds
(42001–42005), and two packet budgets (512,000 and 2,048,000). Each task computes
a fresh temperature followed by six Method-2 images at 1.202812, 2.546353,
3.076480, 3.296169, 9.7 and 18.5 µm: **20 temperatures and 120 images** in total.
Temperature and image packet counts change together. Ten independent frozen
two-model subruns keep seeds/budgets separate without altering existing runs.

It requests **64 CPUs and 16 GB per task**, at most **16 tasks** (1,024 CPUs),
with a 24-hour Slurm limit and a four-hour timeout per MCFOST invocation. These
are initial bounds, not measured runtimes. Keep 64 threads across replicas;
lowering array concurrency to suit the allocation is allowed. A dependent
analysis job requests two CPUs, 4 GB and one hour, and runs after the array even
when some tasks fail.

## Upload and launch

Upload **`extinction_ice_numerics_v2.tar.gz`** from the local `transfer/` folder
to `~/LH-jwst-mcfost/` on the cluster. The archive includes the frozen workflow,
inputs, numerical analyzer, cluster configurator and machine template. No
existing run directory or repository source needs to be overwritten. MCFOST,
its full utilities and the working shared Python environment remain cluster
prerequisites. The `.tar.gz.sha256` sidecar is available for transfer verification.

Extract once into a new directory; do not extract over an experiment already
running or completed. From the cluster project directory:

```bash
cd ~/LH-jwst-mcfost
mkdir -p runs
tar -xzf extinction_ice_numerics_v2.tar.gz -C runs
source ~/.venvs/mcfost-v11/bin/activate
export MCFOST_UTILS=/home/hlo/leshouches/mcfost/utils
```

If required, add your working Slurm `partition`, `account`, `reservation` or
module `setup_lines` under `slurm` in
`runs/extinction_ice_numerics_v2/machine.template.json`. Keep the known-working
`mcfost` on PATH. Then configure using the activated shared environment:

```bash
python -B runs/extinction_ice_numerics_v2/code/configure_cluster.py \
  runs/extinction_ice_numerics_v2 \
  --machine runs/extinction_ice_numerics_v2/machine.template.json

bash runs/extinction_ice_numerics_v2/submit.sh \
  "$PWD/runs/extinction_ice_numerics_v2/machine.template.cluster.json"
```

The first command checks dependencies and frozen files, pins Python/MCFOST/
utility paths, and writes the cluster JSON and Slurm scripts. It submits
nothing. The second submits the array and dependent numerical analysis.
Compute nodes repeat environment checks before execution. The selected Python
must be the shared virtual-environment interpreter, not `/usr/bin/python`.

Do not run `workflow.py prepare` on the V2 design JSON. This package is already
prepared. Do not use the ordinary `workflow.py analyze` on its subruns;
observational ranking is explicitly disabled for numerical-only experiments.

## Status and completion

Replace JOBID with the array ID printed at submission:

```bash
squeue -r -j JOBID -o '%.22i %.10T %.10M %.25R'
sacct -j JOBID -X --format=JobID%22,State%20,NodeList%20,Elapsed,ExitCode

python -B runs/extinction_ice_numerics_v2/code/numerical_task.py \
  runs/extinction_ice_numerics_v2 --status
```

Task logs are `logs/array-JOBID_INDEX.out` and `.err`; analysis has separate
logs. Submission IDs are retained under `submissions/`. File-based status is
not a live scheduler query. If a task fails, inspect its log before resubmitting.
Submitting the package again with the same pinned environment safely reuses
validated completed tasks and resumes incomplete ones; it does not create new
independent samples or relax quality checks.

The numerical analyzer can also be rerun manually after the array finishes:

```bash
python -B runs/extinction_ice_numerics_v2/code/analyze_extinction_ice_numerics_v2.py \
  runs/extinction_ice_numerics_v2
```

Download **`runs/extinction_ice_numerics_v2/results/`**, together with `logs/`,
`experiment.json` and `runtime_binding.json`, for the initial review. Keep the
full run directory on the cluster for raw-image validation and possible follow-up.
Outputs include:

- `numerical_summary.json`: completeness, provenance and numerical decisions.
- `seed_fluxes.csv`: every valid replicate's six aperture fluxes.
- `numerical_scatter.csv`: five-seed scatter and uncertainty by wavelength/case/budget.
- `budget_changes.csv`: paired photon-budget changes and uncertainty.
- `numerical_convergence.png` and `.pdf`: comparison figure.

A completed array is not automatically a numerical pass. At 2.048M packets,
the upper end of the two-sided 95% Gaussian standard-deviation interval,
divided by mean flux, must be ≤1% at every probe. For each paired fractional
change `(high − low)/low`, require `|mean| + 95% t-interval half-width ≤1%`.
Missing replicas, mixed runtimes, invalid products and unresolved bounds cannot
pass. Five identical seed fluxes are reported as degenerate and require review.
The analyzer writes reports even when the experiment is incomplete; an exit
code of 2 means it did not establish a pass. Check the JSON for the reason.

## Scope and preserved assumptions

All calculations use the original **generic coated-Mie dust**. H₂O30K constants
are not needed here. The measurement is a source-centred 1″ signed aperture,
with the inherited Gaussian PSF convention. Model distance remains 140 pc;
aperture/flux evaluation uses 147 pc. Aperture-v2 quality policy keeps harmless
whole-image boundary losses as warnings while enforcing finite flux and
discrete aperture/PSF support. It does not certify image-total/SED closure.

There are no observed flux/error placeholders and no fit ranking. These six
monochromatic probes test sampling noise; they do not implement integrated
MIRI bands, the offset continuum extraction, the 0.35″ H₂O/LSF operator,
material changes, dense SEDs or spatial-resolution convergence. The physical-
contrast criterion (numerical uncertainty below one-third of a claimed
response) remains for later matched physical tests. A pass is conditional on
these two models, six probes and fixed spatial/grain resolution.

Frozen source and product hashes, fresh-temperature receipts, model locks and
the original resumable runner are retained. The package adds a common runtime
identity across all ten subruns, including binary, utilities, thread count,
Python and scientific-package versions. Previously prepared experiments keep
their original frozen code and results.

## Local preparation

From the development workspace, the builder creates a new bundle and archive:

```bash
python -B scripts/build_extinction_ice_numerical_package.py
python -B runs/extinction_ice_numerics_v2/code/numerical_task.py \
  runs/extinction_ice_numerics_v2 --validate
```

It refuses to replace an existing bundle/archive. No MCFOST calculation or
Slurm submission is performed during preparation or package validation.
